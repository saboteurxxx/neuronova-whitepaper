# NEURONOVA — v2.0 WebGL Landing

This package contains the NEURONOVA v2.0 landing page with WebGL animated hex neural logo.

Files:
- index.html
- logo-hex-neural.png
- favicon-32.png
- preview.gif
- js/neuronova-core.js

Deploy: unpack into your repo root and push to GitHub.

Contact: mchefonov37@gmail.com | Telegram: @saboteurxxx
